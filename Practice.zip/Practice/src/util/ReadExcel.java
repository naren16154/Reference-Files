package util;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReadExcel {
	
	public static WebDriver driver = null;
	
	public static void main(String[] args) {
		ReadExcel obj = new ReadExcel();
		obj.openJira();
		obj.getDataFromExcel("ICS-Testcases.xlsx");
	}
	
	public void getDataFromExcel(String excelPath)
	{
		FileInputStream fs=null;
		XSSFWorkbook wb=null;
		try {
			fs = new FileInputStream(excelPath);
			wb = new XSSFWorkbook(fs);
			XSSFSheet ws ;
			int noOfSheets = wb.getNumberOfSheets();
			for(int s=0;s<noOfSheets;s++)
			{
				ws = wb.getSheetAt(s);
				int rownum = ws.getPhysicalNumberOfRows();
				for (int i = 1; i < rownum; i++) {
					String testCaseID = cellToString(ws.getRow(i).getCell(1)); 
					if(null == testCaseID) {
						addTestStep(cellToString(ws.getRow(i).getCell(3)), "",cellToString(ws.getRow(i).getCell(4)));
					}else {
						openTestCase(testCaseID);
						addTestStep(cellToString(ws.getRow(i).getCell(3)), "",cellToString(ws.getRow(i).getCell(4)));
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			try {
				wb.close();
				fs.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

	private void openTestCase(String testCaseID) {
		driver.get("https://jira.oraclecorp.com/jira/browse/EMCSA-"+testCaseID);
		sleep(1000);
	}
		
	private void addTestStep(String... values) {
		driver.findElement(By.xpath("//div[text()='Add Step']")).click();
		List<WebElement> inputs = driver.findElements(By.xpath("//div[@id='editMode']//textarea"));
		int count = 0;
		for(WebElement element : inputs) {
			if(!element.getAttribute("class").equals("editing-field-text-area")) {
				if(null != values[count] || !"".equals(values[count]))
					element.sendKeys(values[count]);
				count++;
			}
		}
		driver.findElement(By.xpath("//img[@data-action='Add Steps']")).click();
		sleep(500);
	}

	private static String cellToString(XSSFCell cell) {
		try{
			int type = cell.getCellType();
			Object result;
			switch (type) {
			case 0:
				result = (long)cell.getNumericCellValue();
				break;
			case 1:
				result = cell.getStringCellValue();
				break;
			case 2:
				result = cell.getBooleanCellValue();
				break;
			case  HSSFCell.CELL_TYPE_BLANK:
				result = null;
				break;
			default:
					result = cell.getRichStringCellValue();
				break;
			}
			return result.toString().trim();
		}catch(NullPointerException e){
			return null;
		}
	}
	
	private void openJira() {
		System.setProperty("webdriver.chrome.driver","/users/npalapar/softwares/selenium/chromedriver");
		driver = new ChromeDriver();
		driver.get("https://jira.oraclecorp.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("sso_username")).sendKeys(System.getProperty("username"));
		driver.findElement(By.id("ssopassword")).sendKeys(System.getProperty("password"));
		driver.findElement(By.id("signin_button")).click();
		sleep(10000);
	}
	
	private void sleep(long inMilliseconds) {
		try {
			Thread.sleep(inMilliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

