const { browser } = require("protractor");
const homePage = require("../pages/HomePage");

describe('angularjs homepage', function () {
    it('should have a title', function () {
        homePage.get()
        expect(browser.getTitle()).toContain('AngularJS');
    });

    it('Verifying greeting text', function(){
        homePage.setName('Narendra')
        expect(homePage.getGreetingText()).toEqual('Hello Narendra!');
    });

});